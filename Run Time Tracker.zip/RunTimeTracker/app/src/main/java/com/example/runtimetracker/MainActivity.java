package com.example.runtimetracker;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void init() {
        TableLayout tableLayout=(TableLayout)findViewById(R.id.main_act_runs_table);

        List<List<Object>> tempItems= Arrays.asList(
                Arrays.asList("00:41:59:12","6","12/02/22"),
                Arrays.asList("00:20:33:42","3","12/02/22")
        );

        for(List<Object> item:tempItems) {
            TableRow row=new TableRow(this);
            TableRow.LayoutParams lp=new TableRow.LayoutParams();
        }
    }
}