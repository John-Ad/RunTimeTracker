package com.example.runtimetracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.sql.Date;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "Runs";
    private static final int DB_VERSION = 1;

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Run("
                + "_id integer primary key autoincrement,"
                + "Run_Time text not null,"
                + "Run_Distance real not null,"
                + "Run_Date numeric not null);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    //-----------------------------
    //       INSERT RUN
    //-----------------------------

    private static void insertRun(SQLiteDatabase db, String time, float dist) {
        ContentValues runValues = new ContentValues();
        runValues.put("Run_Time", time);
        runValues.put("Run_Distance", dist);
        runValues.put("Run_Date", new Date(System.currentTimeMillis()).getTime());
        db.insert("Run", null, runValues);
    }

}
